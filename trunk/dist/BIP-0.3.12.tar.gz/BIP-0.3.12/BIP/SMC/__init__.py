"""
Package with Sequential Monte Carlo routines.
"""
