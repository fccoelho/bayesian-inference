""" 
This package contain classes the deal with Bayesian inference based on numerical representation
of a variable distribution. 
"""
